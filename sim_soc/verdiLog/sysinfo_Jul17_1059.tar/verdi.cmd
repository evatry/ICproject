debImport "-f" "arm926fpga.f"
wvCreateWindow
wvSetPosition -win $_nWave2 {("G1" 0)}
wvOpenFile -win $_nWave2 {/home/ICer/work/sim_soc/wave.fsdb}
srcHBSelect "tbench_top" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top" -delim "."
srcHBSelect "tbench_top" -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "clk" -line 5 -pos 1 -win $_nTrace1
srcSelect -signal "reset_n" -line 6 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
srcHBSelect "tbench_top.dut.u_data_ahb_top" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_data_ahb_top" -delim "."
srcHBSelect "tbench_top.dut.u_data_ahb_top" -win $_nTrace1
srcHBSelect "tbench_top.dut.u_ARM926EJS" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_ARM926EJS" -delim "."
srcHBSelect "tbench_top.dut.u_ARM926EJS" -win $_nTrace1
srcHBSelect "tbench_top.dut.u_data_ahb_top" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_data_ahb_top" -delim "."
srcHBSelect "tbench_top.dut.u_data_ahb_top" -win $_nTrace1
srcSelect -signal "HCLK" -line 120 -pos 2 -win $_nTrace1
srcSelect -toggle -signal "HCLK" -line 120 -pos 2 -win $_nTrace1
srcSelect -signal "HCLK" -line 120 -pos 2 -win $_nTrace1
srcSelect -signal "HRESETn" -line 121 -pos 2 -win $_nTrace1
srcSelect -signal "HWRITE" -line 122 -pos 2 -win $_nTrace1
srcSelect -signal "HTRANS\[1:0\]" -line 123 -pos 1 -win $_nTrace1
srcSelect -signal "HSIZE\[2:0\]" -line 124 -pos 1 -win $_nTrace1
srcSelect -signal "HADDR\[31:0\]" -line 125 -pos 1 -win $_nTrace1
srcSelect -signal "HWDATA\[31:0\]" -line 126 -pos 1 -win $_nTrace1
srcSelect -signal "HRDATA\[31:0\]" -line 127 -pos 1 -win $_nTrace1
srcSelect -signal "HREADY" -line 128 -pos 2 -win $_nTrace1
srcSelect -toggle -signal "HREADY" -line 128 -pos 2 -win $_nTrace1
srcSelect -signal "HREADY" -line 128 -pos 2 -win $_nTrace1
srcSelect -signal "HRESP\[1:0\]" -line 129 -pos 1 -win $_nTrace1
srcSelect -signal "sram_addr\[13:0\]" -line 130 -pos 1 -win $_nTrace1
srcSelect -signal "sram_ce_n" -line 131 -pos 2 -win $_nTrace1
srcSelect -signal "sram_we_n" -line 132 -pos 2 -win $_nTrace1
srcSelect -signal "sram_be_n\[3:0\]" -line 133 -pos 1 -win $_nTrace1
srcSelect -signal "sram_wdata\[31:0\]" -line 134 -pos 1 -win $_nTrace1
srcSelect -signal "sram_rdata\[31:0\]" -line 135 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoom -win $_nWave2 214024706319.174133 214031147730.000305
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
srcDeselectAll -win $_nTrace1
srcSelect -signal "led" -line 161 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
srcHBSelect "tbench_top.dut.u_data_ahb_top.u_sram0" -win $_nTrace1
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_ahb_rom" -delim "."
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
srcSelect -signal "HWRITE" -line 11 -pos 1 -win $_nTrace1
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut" -delim "."
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcSelect -signal "IHADDR\[31:0\]" -line 109 -pos 1 -win $_nTrace1
srcSelect -signal "IHTRANS\[1:0\]" -line 110 -pos 1 -win $_nTrace1
srcSelect -signal "IHBURST\[2:0\]" -line 111 -pos 1 -win $_nTrace1
srcSelect -toggle -signal "IHBURST\[2:0\]" -line 111 -pos 1 -win $_nTrace1
srcSelect -signal "IHBURST\[2:0\]" -line 111 -pos 1 -win $_nTrace1
srcSelect -signal "IHWRITE" -line 112 -pos 2 -win $_nTrace1
srcSelect -signal "IHSIZE\[2:0\]" -line 113 -pos 1 -win $_nTrace1
srcSelect -signal "IHPROT\[3:0\]" -line 114 -pos 1 -win $_nTrace1
srcSelect -signal "IHBUSREQ" -line 115 -pos 2 -win $_nTrace1
srcSelect -signal "IHLOCK" -line 116 -pos 2 -win $_nTrace1
srcSelect -signal "IHREADY" -line 184 -pos 2 -win $_nTrace1
srcSelect -signal "IHRESP\[1:0\]" -line 185 -pos 1 -win $_nTrace1
srcSelect -signal "IHRDATA\[31:0\]" -line 186 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
wvZoom -win $_nWave2 2159620.296372 2464214.141640
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 26 )} 
wvSelectSignal -win $_nWave2 {( "G1" 26 )} 
wvSelectSignal -win $_nWave2 {( "G1" 26 )} 
wvScrollUp -win $_nWave2 13
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
srcDeselectAll -win $_nTrace1
srcSelect -signal "HCLK" -line 78 -pos 1 -win $_nTrace1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvSetPosition -win $_nWave2 {("G1" 3)}
wvSetPosition -win $_nWave2 {("G1" 4)}
wvSetPosition -win $_nWave2 {("G1" 5)}
wvSetPosition -win $_nWave2 {("G1" 6)}
wvSetPosition -win $_nWave2 {("G1" 7)}
wvSetPosition -win $_nWave2 {("G1" 8)}
wvSetPosition -win $_nWave2 {("G1" 9)}
wvSetPosition -win $_nWave2 {("G1" 10)}
wvSetPosition -win $_nWave2 {("G1" 11)}
wvSetPosition -win $_nWave2 {("G1" 12)}
wvSetPosition -win $_nWave2 {("G1" 13)}
wvSetPosition -win $_nWave2 {("G1" 14)}
wvSetPosition -win $_nWave2 {("G1" 15)}
wvSetPosition -win $_nWave2 {("G1" 16)}
wvSetPosition -win $_nWave2 {("G1" 17)}
wvSetPosition -win $_nWave2 {("G1" 18)}
wvSetPosition -win $_nWave2 {("G1" 19)}
wvSetPosition -win $_nWave2 {("G1" 20)}
wvSetPosition -win $_nWave2 {("G1" 21)}
wvSetPosition -win $_nWave2 {("G1" 22)}
wvSetPosition -win $_nWave2 {("G1" 23)}
wvSetPosition -win $_nWave2 {("G1" 24)}
wvSetPosition -win $_nWave2 {("G1" 25)}
wvSetPosition -win $_nWave2 {("G1" 26)}
wvSetPosition -win $_nWave2 {("G1" 27)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1" 29)}
wvSetPosition -win $_nWave2 {("G1" 30)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G1" 30)}
wvSetPosition -win $_nWave2 {("G1" 29)}
wvSetPosition -win $_nWave2 {("G2" 0)}
wvSetPosition -win $_nWave2 {("G1" 30)}
wvSetPosition -win $_nWave2 {("G1" 29)}
wvSetPosition -win $_nWave2 {("G1" 28)}
wvSetPosition -win $_nWave2 {("G1" 20)}
wvSetPosition -win $_nWave2 {("G1" 19)}
wvMoveSelected -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 19)}
wvSelectSignal -win $_nWave2 {( "G1" 26 )} 
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 2384090.646588 2533922.316357
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_ahb_rom" -delim "."
srcHBSelect "tbench_top.dut.u_ahb_rom" -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rom_addr" -line 21 -pos 1 -win $_nTrace1
srcSelect -signal "rom_ce_n" -line 22 -pos 1 -win $_nTrace1
srcSelect -signal "rom_oe_n" -line 23 -pos 1 -win $_nTrace1
srcSelect -toggle -signal "rom_oe_n" -line 23 -pos 1 -win $_nTrace1
wvSetCursor -win $_nWave2 2445510.083473 -snap {("G1" 24)}
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSelectSignal -win $_nWave2 {( "G1" 30 )} 
srcDeselectAll -win $_nTrace1
wvSetPosition -win $_nWave2 {("G1" 30)}
srcSelect -signal "rom_addr" -line 21 -pos 1 -win $_nTrace1
srcSelect -signal "rom_ce_n" -line 22 -pos 1 -win $_nTrace1
srcSelect -signal "rom_oe_n" -line 23 -pos 1 -win $_nTrace1
srcSelect -signal "rom_data" -line 24 -pos 1 -win $_nTrace1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSelectSignal -win $_nWave2 {( "G1" 3 )} 
wvScrollDown -win $_nWave2 13
wvSelectSignal -win $_nWave2 {( "G1" 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 \
           19 20 21 22 23 24 25 26 27 28 29 30 )} 
wvCut -win $_nWave2
wvSetPosition -win $_nWave2 {("G1" 2)}
srcSelect -signal "HWRITE" -line 11 -pos 1 -win $_nTrace1
srcSelect -signal "HTRANS" -line 12 -pos 1 -win $_nTrace1
srcSelect -signal "HADDR" -line 13 -pos 1 -win $_nTrace1
srcSelect -signal "HWDATA" -line 14 -pos 1 -win $_nTrace1
srcSelect -signal "HSIZE" -line 15 -pos 1 -win $_nTrace1
srcSelect -signal "HBURST" -line 16 -pos 1 -win $_nTrace1
srcSelect -signal "HPROT" -line 17 -pos 1 -win $_nTrace1
srcSelect -signal "HRDATA" -line 18 -pos 1 -win $_nTrace1
srcSelect -signal "HREADY" -line 19 -pos 1 -win $_nTrace1
srcSelect -signal "HRESP" -line 20 -pos 1 -win $_nTrace1
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut" -delim "."
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcSelect -signal "IHWRITE" -line 268 -pos 1 -win $_nTrace1
srcSelect -signal "IHTRANS\[1:0\]" -line 269 -pos 1 -win $_nTrace1
srcSelect -signal "IHADDR\[31:0\]" -line 270 -pos 1 -win $_nTrace1
srcSelect -signal "IHSIZE\[2:0\]" -line 272 -pos 1 -win $_nTrace1
srcSelect -signal "IHBURST\[2:0\]" -line 273 -pos 1 -win $_nTrace1
srcSelect -signal "IHPROT\[3:0\]" -line 274 -pos 1 -win $_nTrace1
srcSelect -signal "IHRDATA\[31:0\]" -line 275 -pos 1 -win $_nTrace1
srcSelect -signal "IHREADY" -line 276 -pos 1 -win $_nTrace1
srcSelect -signal "IHRESP\[1:0\]" -line 277 -pos 1 -win $_nTrace1
srcSelect -signal "rom_addr\[13:0\]" -line 278 -pos 1 -win $_nTrace1
srcSelect -signal "rom_ce_n" -line 279 -pos 2 -win $_nTrace1
srcSelect -signal "rom_oe_n" -line 280 -pos 2 -win $_nTrace1
srcSelect -signal "rom_data\[31:0\]" -line 281 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoom -win $_nWave2 2377290.667935 2666753.521285
wvSetCursor -win $_nWave2 901424.879278 -snap {("G1" 4)}
wvSetCursor -win $_nWave2 1790314.720455 -snap {("G1" 5)}
wvSearchPrev -win $_nWave2
wvSearchPrev -win $_nWave2
srcDeselectAll -win $_nTrace1
srcSelect -inst "u_ahb_rom" -line 265 -pos 1 -win $_nTrace1
srcAction -pos 264 11 4 -win $_nTrace1 -name "u_ahb_rom" -ctrlKey off
srcDeselectAll -win $_nTrace1
srcSearchString "DADDR" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
nsMsgSwitchTab -tab search
srcSearchString "DREAD" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut" -delim "."
srcHBSelect "tbench_top.dut" -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "DHADDR\[31:0\]" -line 298 -pos 1 -win $_nTrace1
srcSelect -signal "DHWRITE" -line 299 -pos 1 -win $_nTrace1
srcSelect -signal "DHTRANS\[1:0\]" -line 300 -pos 1 -win $_nTrace1
srcSelect -signal "DHSIZE\[2:0\]" -line 301 -pos 1 -win $_nTrace1
srcSelect -signal "DHBURST\[2:0\]" -line 302 -pos 1 -win $_nTrace1
srcSelect -signal "DHPROT\[3:0\]" -line 303 -pos 1 -win $_nTrace1
srcSelect -signal "DHWDATA\[31:0\]" -line 304 -pos 1 -win $_nTrace1
srcSelect -signal "DHRDATA\[31:0\]" -line 305 -pos 1 -win $_nTrace1
srcSelect -signal "DHREADY" -line 306 -pos 1 -win $_nTrace1
srcSelect -signal "DHRESP\[1:0\]" -line 307 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
srcDeselectAll -win $_nTrace1
srcSearchString "PC_IF" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
srcSearchString "PC_IF" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
srcSearchString "PC" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
nsMsgSelect -range {4 14 2-2}
nsMsgAction -tab search -index {4 14 2}
nsMsgSelect -range {4 14 2-2}
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoom -win $_nWave2 1792880.287171 1848653.476641
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 1720520.215630 -snap {("G1" 7)}
wvZoom -win $_nWave2 1729690.373950 1876412.907071
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
srcHBSelect "tbench_top.dut.u_ARM926EJS.uCORE" -win $_nTrace1
srcSetScope -win $_nTrace1 "tbench_top.dut.u_ARM926EJS.uCORE" -delim "."
srcHBSelect "tbench_top.dut.u_ARM926EJS.uCORE" -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {143 143 4 4 2 4}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {895 895 4 4 3 5}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {959 959 3 3 2 4}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {959 959 6 6 2 4}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {1023 1023 3 3 3 5}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {1023 1023 6 6 3 5}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {1331 1331 3 3 2 4}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {1331 1331 6 6 3 5}
srcSearchString "PC" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {31 31 17 17 2 4}
nsMsgSwitchTab -tab general
srcSearchString "PC_IF" -win $_nTrace1 -next -case -allfiles -fileType "*.*"
nsMsgSwitchTab -tab search
srcSearchString "CP15" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {389 389 2 3 21 1}
srcSearchString "CP15" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {390 390 4 4 1 5}
srcSearchString "CP15" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {391 391 4 4 1 5}
srcSearchString "CP15" -win $_nTrace1 -next -case
srcSelect -win $_nTrace1 -range {401 401 4 4 1 5}
srcDeselectAll -win $_nTrace1
srcSelect -signal "CP15DbgClkEn" -line 401 -pos 1 -win $_nTrace1
srcAddSelectedToWave -clipboard -win $_nTrace1
wvDrop -win $_nWave2
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
